$("#content-button, #sidebar").click(() => {
  $("#sidebar").toggle()
})
